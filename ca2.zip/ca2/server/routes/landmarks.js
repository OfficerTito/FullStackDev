const router = require(`express`).Router()

const landmarksModel = require(`../models/landmarks`)

// read all records
router.get(`/landmarks`, (req, res) => 
{   
    landmarksModel.find((error, data) => 
    {
        res.json(data)
    })
})


// Read one record
router.get(`/landmarks/:id`, (req, res) => 
{
    landmarksModel.findById(req.params.id, (error, data) => 
    {              
        res.json(data)
    })
})



module.exports = router