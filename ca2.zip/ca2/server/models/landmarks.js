
const mongoose = require(`mongoose`)

let landmarksSchema = new mongoose.Schema(
   {

      //   _id:{type:ObjectId},
      //   context: {type: String},
      //   type: {type: String},
        name: {type:String, required:true},
      //   address:{
      //    type:{type:String},
      //    addressCountry: {type: String,match:["Republic of Ireland","Country is not in ireland"]},
      //    addressLocality: {type: String,enum:addressLocalities},
      //    addressRegion: {type: String,enum:["Galway", "Leitrim", "Mayo", "Roscommon", "Sligo","Carlow","Dublin","Kildare","Kilkenny","Laois","Longford","Louth","Meath","Offaly", "Westmeath","Wexford","Wicklow","Clare","Cork","Kerry","Limerick","Tipperary","Waterford","Cavan","Monaghan","Donegal"]},
      //   },
      //   geo:{
      //    type:{type:String},
      //    latitude: {type: Number, min:-90, max:90},
      //    longitude: {type: Number, min:180, max:180},
      //   },
      
      //   images:{ 
      //    caption:{type:String},
      //    url:{type:String,match:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/},
      //   },
      telephone: {type: String, min:7, max: 13},
      //   tags:{type:String,},
      //   telephone: {type: String, min:7, max: 13, match:[/^+([0-9]{13})$/]},
      //   url:{type:String,match:/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/},


   },
   {
      collection:`landmarks`
   })

module.exports = mongoose.model(`landmarks`, landmarksSchema)
