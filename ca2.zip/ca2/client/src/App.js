import React, {Component} from "react"
import {BrowserRouter, Switch, Route} from "react-router-dom"

import "bootstrap/dist/css/bootstrap.css"
import "./css/App.css"


import DisplayAllLandmarks from "./components/DisplayAllLandmarks"

    
export default class App extends Component 
{
    render() 
    {
        return (
            <BrowserRouter>
                <Switch>                 
                    <Route exact path="/" component={DisplayAllLandmarks} />
                    <Route exact path="/DisplayAllLandmarks" component={DisplayAllLandmarks}/> 
                    <Route path="*" component={DisplayAllLandmarks}/>                            
                </Switch>
            </BrowserRouter>
        )
    }
}